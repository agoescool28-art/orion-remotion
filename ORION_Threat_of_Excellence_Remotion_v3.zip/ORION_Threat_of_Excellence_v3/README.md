# ORION Motion Graphic Engine v3 — The Threat of Excellence

Versi visual dinamis: palet merah-putih-hitam, layout berganti tiap beat, kinetic typography, kartu editorial, diagram simbolis, dan transisi cepat namun terarah.

## Jalankan di Codespaces
```bash
npm install
npm run start
```
Untuk render MP4:
```bash
npm run render
```
Output: `out/orion-threat-of-excellence-v3.mp4`

Komposisi: 1080×1920, 30 FPS, 2236 frame (±74,53 detik). Audio asli berada di `public/voiceover.mp3`.

import React from 'react';
import {AbsoluteFill, Audio, Composition, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

const W=1080,H=1920,FPS=30;
const palette={ink:'#111114',paper:'#F7F5F0',red:'#E83D32',redDark:'#A91F27',grey:'#6C6A68',line:'#D7D3CB',white:'#FFFFFF',yellow:'#FFD65A'};
type Beat={from:number;duration:number;eyebrow:string;title:string[];sub:string;kind:string;theme:'dark'|'paper'|'red'};
const beats:Beat[]=[
 {from:0,duration:250,eyebrow:'ORION PRESENTS / REAL TALK',title:['ORANG HEBAT','BISA DIANGGAP','ANCAMAN.'],sub:'Mengapa keunggulan kadang memicu penolakan?',kind:'hook',theme:'red'},
 {from:250,duration:280,eyebrow:'01 — STATUS & PENGARUH',title:['KETIKA','STANDAR NAIK,','EGO TERUSIK.'],sub:'Kemampuan baru bisa mengubah keseimbangan di dalam tim.',kind:'status',theme:'paper'},
 {from:530,duration:280,eyebrow:'02 — RESISTENSI',title:['“DARI DULU','JUGA BEGITU.”'],sub:'Kenyamanan sering menyamar sebagai alasan untuk tidak berubah.',kind:'resistance',theme:'dark'},
 {from:810,duration:280,eyebrow:'03 — TEKANAN SOSIAL',title:['BERBEDA','BUKAN BERARTI','SALAH.'],sub:'Kadang gagasan baru ditolak sebelum benar-benar diuji.',kind:'social',theme:'red'},
 {from:1090,duration:280,eyebrow:'04 — CERMIN DIRI',title:['TAPI…','JANGAN LUPA','BERKACA.'],sub:'Kompetensi tanpa empati bisa berubah menjadi kesombongan.',kind:'mirror',theme:'paper'},
 {from:1370,duration:280,eyebrow:'05 — INTEGRITAS',title:['TEGAS PADA','PRINSIP.','TERBUKA PADA KRITIK.'],sub:'Buktikan lewat hasil, komunikasi, dan kemauan belajar.',kind:'principle',theme:'dark'},
 {from:1650,duration:280,eyebrow:'06 — LINGKUNGAN SEHAT',title:['BUAT RUANG','UNTUK','BERTUMBUH.'],sub:'Tim yang kuat tidak takut pada orang yang terus berkembang.',kind:'growth',theme:'paper'},
 {from:1930,duration:306,eyebrow:'ORION / TAKEAWAY',title:['JANGAN KECILKAN','CAHAYA ORANG LAIN.'],sub:'Bertumbuh bersama. Tetap rendah hati.',kind:'end',theme:'dark'}
];
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const Person:React.FC<{x:number;y:number;s?:number;color:string;opacity?:number}>=({x,y,s=1,color,opacity=1})=><g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}><ellipse cx="0" cy="122" rx="37" ry="8" fill="#000" opacity=".15"/><circle cx="0" cy="-55" r="19" fill={color}/><path d="M-27 -27Q0 -40 27 -27L37 45H-37Z" fill={color}/><path d="M-23 45L-29 118H-7L0 61L7 118H29L23 45Z" fill={color}/></g>;
const Graphic:React.FC<{kind:string;p:number;accent:string;dark:boolean}>=({kind,p,accent,dark})=>{
 const fg=dark?palette.paper:palette.ink; const drift=Math.sin(p*Math.PI*2)*26;
 if(kind==='hook')return <g><circle cx={760+drift} cy="790" r={270} fill="none" stroke={palette.paper} strokeWidth="2" opacity=".35"/><circle cx={760+drift} cy="790" r={190} fill="none" stroke={palette.paper} strokeWidth="30" strokeDasharray="12 20" opacity=".8"/><path d="M520 470L930 1120H620Z" fill={palette.ink} opacity=".24"/><Person x={750+drift} y={1180} s={1.5} color={palette.paper}/><path d="M520 1260H980" stroke={palette.paper} strokeWidth="6"/></g>;
 if(kind==='status')return <g><rect x="570" y="650" width="360" height="420" rx="18" fill={palette.red}/><rect x="620" y="590" width="260" height="55" rx="8" fill={palette.ink}/>{[0,1,2,3].map(i=><rect key={i} x={610+i*85} y={900-i*65} width="54" height={120+i*65} fill={i===3?palette.yellow:palette.paper}/>)}<Person x={500+drift} y={1180} s={1.05} color={palette.ink}/><path d="M430 1240L960 1240" stroke={palette.line} strokeWidth="5"/></g>;
 if(kind==='resistance')return <g>{[0,1,2,3].map(i=><g key={i} transform={`translate(${250+i*190} ${830+(i%2)*35}) rotate(${p*25*(i%2?1:-1)})`}><circle r={75} fill="none" stroke={i===2?palette.red:palette.paper} strokeWidth="15" strokeDasharray="22 12"/><circle r="24" fill={palette.red}/></g>)}<path d={`M150 ${1190+drift}L390 1040L600 1110L890 890`} stroke={palette.red} strokeWidth="9" fill="none" strokeLinecap="round"/></g>;
 if(kind==='social')return <g><path d="M560 510L930 1170H190Z" fill={palette.paper} opacity=".1"/><Person x={560} y={1130} s={1.35} color={palette.paper}/>{[0,1,2,3,4].map(i=><g key={i}><path d={`M${100+i*205} 690q45 -70 90 0t90 0`} fill="none" stroke={palette.paper} strokeWidth="5" opacity=".65"/><circle cx={150+i*195} cy={900+(i%2)*45} r="16" fill={i===2?palette.yellow:palette.paper}/></g>)}</g>;
 if(kind==='mirror')return <g><path d="M560 450L850 570V1150L560 1270L270 1150V570Z" fill={palette.paper} stroke={palette.red} strokeWidth="8"/><path d="M560 450V1270" stroke={palette.line} strokeWidth="5"/><Person x={450} y={1130} s={.9} color={palette.ink}/><Person x={680} y={1130} s={.9} color={palette.red}/><circle cx={560} cy={760} r={60+15*p} fill={palette.red} opacity=".2"/></g>;
 if(kind==='principle')return <g><rect x="210" y="700" width="660" height="390" rx="28" fill="#242429" stroke={palette.red} strokeWidth="5"/><path d="M300 850H780M300 930H680" stroke={palette.paper} strokeWidth="14" strokeLinecap="round" opacity=".7"/><path d="M310 1010L420 1070L720 760" stroke={palette.yellow} strokeWidth="22" fill="none" strokeLinecap="round" strokeLinejoin="round"/><circle cx={850+drift} cy="620" r="45" fill={palette.red}/></g>;
 if(kind==='growth')return <g><path d="M100 1240Q540 930 980 1240" fill="none" stroke={palette.line} strokeWidth="110"/><path d="M100 1240Q540 930 980 1240" fill="none" stroke={palette.red} strokeWidth="7" strokeDasharray="18 20"/>{[0,1,2,3,4].map(i=><Person key={i} x={250+i*145} y={1120+(i%2)*24} s={.58} color={i===2?palette.red:palette.ink}/>)}<circle cx={540} cy={780} r={180+20*p} fill="none" stroke={palette.red} strokeWidth="5" opacity=".65"/></g>;
 return <g><circle cx={540} cy={820} r={240+22*p} fill="none" stroke={palette.red} strokeWidth="4"/><circle cx={540} cy={820} r="145" fill={palette.red} opacity=".15"/><path d="M180 1180H900" stroke={palette.red} strokeWidth="8"/><Person x={540} y={1160} s={1.2} color={palette.paper}/></g>;
};
const Scene:React.FC<{b:Beat;idx:number}>=({b,idx})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig(); const s=spring({frame:f,fps,config:{damping:16,mass:.7}}); const p=f/b.duration;
 const dark=b.theme==='dark'; const bg=b.theme==='red'?`linear-gradient(145deg, ${palette.red} 0%, ${palette.redDark} 100%)`:dark?`radial-gradient(ellipse at 70% 45%, #29292F 0%, #111114 70%)`:palette.paper;
 const fg=dark||b.theme==='red'?palette.paper:palette.ink; const accent=b.theme==='red'?palette.yellow:palette.red;
 const fade=interpolate(f,[0,12,b.duration-14,b.duration],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const size=b.title.join('').length>24?74:b.title.length===3?88:96;
 const titleTop=b.kind==='hook'?280:b.kind==='end'?350:300;
 return <AbsoluteFill style={{background:bg,color:fg,opacity:fade,overflow:'hidden',fontFamily:'Arial, Helvetica, sans-serif'}}>
   <div style={{position:'absolute',inset:0,opacity:.13,backgroundImage:`linear-gradient(90deg, transparent 49.8%, ${fg} 50%, transparent 50.2%), linear-gradient(0deg, transparent 49.8%, ${fg} 50%, transparent 50.2%)`,backgroundSize:'120px 120px',transform:`translate(${Math.sin(p*5)*20}px,${Math.cos(p*4)*15}px)`}}/>
   <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position:'absolute',inset:0,transform:`scale(${interpolate(s,[0,1],[1.08,1])})`}}><Graphic kind={b.kind} p={p} accent={accent} dark={dark}/></svg>
   <div style={{position:'absolute',left:70,top:90,fontSize:20,fontWeight:800,letterSpacing:3,color:accent}}>{b.eyebrow}</div>
   <div style={{position:'absolute',left:66,right:58,top:titleTop+interpolate(s,[0,1],[65,0]),fontSize:size,fontWeight:900,lineHeight:.98,letterSpacing:-3,textTransform:'uppercase'}}>{b.title.map((line,i)=><div key={line} style={{width:'fit-content',maxWidth:'100%',marginBottom:8,padding:'3px 9px 9px',background:(i===b.title.length-1 && (b.theme==='red'||i%2===1))?accent:'transparent',color:(i===b.title.length-1 && (b.theme==='red'||i%2===1))?(b.theme==='red'?palette.ink:palette.paper):fg,transform:`translateX(${interpolate(f,[5+i*7,22+i*7],[i%2===0?-70:70,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}px)`,opacity:interpolate(f,[4+i*7,18+i*7],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>{line}</div>)}</div>
   <div style={{position:'absolute',left:78,right:90,top:640,fontSize:30,lineHeight:1.35,fontWeight:500,maxWidth:820,opacity:interpolate(f,[28,44],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),borderLeft:`6px solid ${accent}`,paddingLeft:22}}>{b.sub}</div>
   <div style={{position:'absolute',left:75,bottom:104,fontSize:17,letterSpacing:3,fontWeight:700,opacity:.75}}>ORION / MOTION STORIES</div><div style={{position:'absolute',right:75,bottom:104,fontSize:19,fontWeight:800,color:accent}}>{String(idx+1).padStart(2,'0')} — 08</div>
   <div style={{position:'absolute',left:75,bottom:75,width:930,height:3,background:fg,opacity:.18}}/><div style={{position:'absolute',left:75,bottom:75,width:930*clamp((b.from+f)/2236),height:3,background:accent}}/>
 </AbsoluteFill>;
};
export const OrionThreatOfExcellence:React.FC=()=> <AbsoluteFill style={{background:palette.ink}}><Audio src={staticFile('voiceover.mp3')} volume={1}/>{beats.map((b,i)=><Sequence key={i} from={b.from} durationInFrames={b.duration}><Scene b={b} idx={i}/></Sequence>)}</AbsoluteFill>;
export const RemotionRoot:React.FC=()=> <Composition id="OrionThreatOfExcellence" component={OrionThreatOfExcellence} durationInFrames={2236} fps={FPS} width={W} height={H}/>;

import {ArtDirection, ContentType, Mood, ProjectBrief, VisualStyle} from './types';

type StyleProfile = {style: VisualStyle; label: string; palette: string[]; motif: string; typography: ArtDirection['typography']; camera: string};

const profiles: Record<VisualStyle, StyleProfile> = {
  cinematic: {style:'cinematic',label:'Cinematic Narrative',palette:['#101820','#E8E1D5','#D97745'],motif:'light, silhouette, atmospheric depth',typography:'editorial',camera:'slow push, motivated pan, layered depth'},
  'technical-3d': {style:'technical-3d',label:'Technical 3D',palette:['#101820','#DCE7E8','#F06A45'],motif:'mechanical parts, cutaway, exploded assembly',typography:'technical',camera:'orbit, close-up, sectional reveal'},
  editorial: {style:'editorial',label:'Editorial Motion',palette:['#F4F0E8','#202321','#E36D3F'],motif:'bold type, diagram, visual metaphor',typography:'kinetic',camera:'graphic scale, precise lateral movement'},
  character: {style:'character',label:'Character Explainer',palette:['#F5EBDD','#252525','#E77D68'],motif:'expressive character, gesture, prop interaction',typography:'editorial',camera:'staged medium shot, reaction close-up'},
  isometric: {style:'isometric',label:'Isometric Simulation',palette:['#EDEFE9','#263238','#D98A43'],motif:'modular environment, process path, moving units',typography:'technical',camera:'isometric tracking, zone reveal'},
  'futuristic-data': {style:'futuristic-data',label:'Futuristic Data',palette:['#0A1118','#E8F2F2','#F18B45'],motif:'data nodes, interface, signal paths',typography:'interface',camera:'interface push, node-to-node travel'},
};

const scores: Record<ContentType, Partial<Record<VisualStyle, number>>> = {
  story: {cinematic:10,editorial:5,character:4,'futuristic-data':1,'technical-3d':2,isometric:1},
  education: {editorial:9,character:7,cinematic:5,'technical-3d':4,isometric:3,'futuristic-data':3},
  technical: {'technical-3d':10,editorial:5,cinematic:4,isometric:6,'futuristic-data':4,character:1},
  process: {isometric:10,'technical-3d':8,editorial:4,cinematic:3,'futuristic-data':3,character:1},
  data: {'futuristic-data':10,editorial:8,'technical-3d':3,cinematic:3,isometric:2,character:1},
  reflection: {cinematic:9,editorial:8,character:4,'futuristic-data':1,'technical-3d':1,isometric:1},
};

export function selectArtDirection(brief: ProjectBrief, forcedStyle?: VisualStyle): ArtDirection {
  const ranked = (Object.keys(profiles) as VisualStyle[])
    .map(style => ({style, score: scores[brief.contentType][style] ?? 0}))
    .sort((a,b) => b.score-a.score);
  const primaryStyle = forcedStyle ?? ranked[0].style;
  const secondaryStyles = ranked.filter(x => x.style !== primaryStyle && x.score >= Math.max(3, (ranked[0].score ?? 0)-4)).slice(0,2).map(x=>x.style);
  const profile = profiles[primaryStyle];
  return {primaryStyle,secondaryStyles,palette:profile.palette,motif:profile.motif,typography:profile.typography,cameraLanguage:profile.camera};
}

export function explainStyleChoice(brief: ProjectBrief): string {
  const direction = selectArtDirection(brief);
  return `${profiles[direction.primaryStyle].label} dipilih untuk tipe konten ${brief.contentType}; mood ${brief.mood}. Gaya pendukung: ${direction.secondaryStyles.join(', ') || 'tidak diperlukan'}.`;
}

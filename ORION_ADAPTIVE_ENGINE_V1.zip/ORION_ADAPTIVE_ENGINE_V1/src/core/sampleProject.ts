import {OrionProject} from './types';
import {selectArtDirection} from './adaptiveArtDirector';

const brief = {
  title: 'Satu Sistem, Banyak Bahasa Visual',
  topic: 'Bagaimana teknologi dan proses membentuk masa depan',
  audience: 'Penonton umum dan profesional muda',
  objective: 'Menunjukkan bahwa ide yang berbeda membutuhkan cara visual yang berbeda',
  contentType: 'education' as const,
  mood: 'curious' as const,
  durationSeconds: 60,
  width: 1080,
  height: 1920,
  fps: 30,
};

export const sampleProject: OrionProject = {
  brief,
  artDirection: selectArtDirection(brief),
  scenes: [
    {id:'s01',durationSeconds:10,style:'cinematic',eyebrow:'ORION / ADAPTIVE STORYTELLING',headline:'Setiap ide punya cara bercerita.',body:'Visual yang tepat membuat pesan lebih mudah dirasakan dan dipahami.',visualPurpose:'Membangun rasa ingin tahu dan membuka gagasan'},
    {id:'s02',durationSeconds:10,style:'editorial',eyebrow:'01 / CLARITY',headline:'Ide harus menjadi jelas.',body:'Tipografi, metafora, dan komposisi mengarahkan perhatian pada inti pesan.',visualPurpose:'Menekankan hierarki dan pemahaman'},
    {id:'s03',durationSeconds:10,style:'technical-3d',eyebrow:'02 / MECHANISM',headline:'Mekanisme perlu diperlihatkan.',body:'Ketika membahas mesin, bentuk dan hubungan antarkomponen harus terlihat.',visualPurpose:'Menjelaskan struktur dan hubungan komponen'},
    {id:'s04',durationSeconds:10,style:'character',eyebrow:'03 / HUMAN',headline:'Perilaku lebih mudah dipahami lewat aksi.',body:'Gesture, ekspresi, dan interaksi mengubah konsep menjadi pengalaman manusia.',visualPurpose:'Memberi contoh perilaku yang mudah dikenali'},
    {id:'s05',durationSeconds:10,style:'isometric',eyebrow:'04 / SYSTEM',headline:'Proses harus terlihat bergerak.',body:'Alur, perpindahan, dan hubungan antarbagian membentuk gambaran utuh.',visualPurpose:'Menjelaskan aliran kerja dan sistem'},
    {id:'s06',durationSeconds:10,style:'futuristic-data',eyebrow:'05 / SIGNAL',headline:'Data mengungkap pola.',body:'Informasi menjadi bermakna ketika hubungan dan perubahannya terlihat.',visualPurpose:'Menghubungkan data dan insight'},
  ],
};

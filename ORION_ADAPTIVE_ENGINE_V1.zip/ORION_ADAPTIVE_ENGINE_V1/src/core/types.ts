import React from 'react';

export type VisualStyle = 'cinematic' | 'technical-3d' | 'editorial' | 'character' | 'isometric' | 'futuristic-data';
export type ContentType = 'story' | 'education' | 'technical' | 'process' | 'data' | 'reflection';
export type Mood = 'inspiring' | 'serious' | 'curious' | 'urgent' | 'warm' | 'contemplative';

export type ProjectBrief = {
  title: string;
  topic: string;
  audience: string;
  objective: string;
  contentType: ContentType;
  mood: Mood;
  durationSeconds: number;
  width: number;
  height: number;
  fps: number;
};

export type ArtDirection = {
  primaryStyle: VisualStyle;
  secondaryStyles: VisualStyle[];
  palette: string[];
  motif: string;
  typography: 'editorial' | 'kinetic' | 'technical' | 'interface';
  cameraLanguage: string;
};

export type SceneBeat = {
  id: string;
  durationSeconds: number;
  style: VisualStyle;
  eyebrow: string;
  headline: string;
  body: string;
  visualPurpose: string;
  narration?: string;
  emphasis?: string[];
};

export type OrionProject = {
  brief: ProjectBrief;
  artDirection: ArtDirection;
  scenes: SceneBeat[];
};

export type StyleRendererProps = {
  scene: SceneBeat;
  frame: number;
  fps: number;
  accent: string;
  index: number;
};

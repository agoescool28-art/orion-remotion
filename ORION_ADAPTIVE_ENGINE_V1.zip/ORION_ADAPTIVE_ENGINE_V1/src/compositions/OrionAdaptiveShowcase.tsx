import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {sampleProject} from '../core/sampleProject';
import {AdaptiveScene} from '../components/AdaptiveScene';

export const ORION_ADAPTIVE_SHOWCASE_ID = 'OrionAdaptiveShowcaseV1';
export const ORION_ADAPTIVE_TRANSITION_FRAMES = 18;
export const ORION_ADAPTIVE_SHOWCASE_DURATION = sampleProject.scenes.reduce((sum,s)=>sum+s.durationSeconds*sampleProject.brief.fps,0) - (sampleProject.scenes.length-1)*ORION_ADAPTIVE_TRANSITION_FRAMES;

export const OrionAdaptiveShowcase:React.FC<{audioFile?:string}> = ({audioFile}) => {
  const {brief,scenes,artDirection}=sampleProject;
  let cursor=0;
  const starts=scenes.map((scene,index)=>{const start=cursor;cursor+=scene.durationSeconds*brief.fps-(index<scenes.length-1?ORION_ADAPTIVE_TRANSITION_FRAMES:0);return start;});
  return <AbsoluteFill style={{background:'#101820'}}>
    {scenes.map((scene,index)=><Sequence key={scene.id} from={starts[index]} durationInFrames={scene.durationSeconds*brief.fps} premountFor={brief.fps}>
      <AdaptiveScene scene={scene} fps={brief.fps} index={index} accent={artDirection.palette[2]} transitionFrames={ORION_ADAPTIVE_TRANSITION_FRAMES}/>
    </Sequence>)}
    {audioFile ? <Audio src={staticFile(audioFile)} volume={0.85}/> : null}
  </AbsoluteFill>;
};

import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {SceneBeat, VisualStyle} from '../core/types';
import {CinematicRenderer,EditorialRenderer,Technical3DRenderer,CharacterRenderer,IsometricRenderer,FuturisticDataRenderer} from '../styles/StyleRenderers';

const renderers: Record<VisualStyle, React.FC<any>> = {
  cinematic:CinematicRenderer,
  editorial:EditorialRenderer,
  'technical-3d':Technical3DRenderer,
  character:CharacterRenderer,
  isometric:IsometricRenderer,
  'futuristic-data':FuturisticDataRenderer,
};

export const AdaptiveScene:React.FC<{scene:SceneBeat;fps:number;index:number;accent:string;transitionFrames?:number}> = ({scene,fps,index,accent,transitionFrames=18}) => {
  const frame=useCurrentFrame();
  const fadeIn=interpolate(frame,[0,transitionFrames],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const fadeOut=interpolate(frame,[scene.durationSeconds*fps-transitionFrames,scene.durationSeconds*fps],[1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const Renderer=renderers[scene.style];
  return <AbsoluteFill style={{opacity:Math.min(fadeIn,fadeOut)}}>
    <Renderer scene={scene} frame={frame} fps={fps} accent={accent} index={index}/>
  </AbsoluteFill>;
};

import React from 'react';
import {Composition} from 'remotion';
import {OrionAdaptiveShowcase,ORION_ADAPTIVE_SHOWCASE_DURATION,ORION_ADAPTIVE_SHOWCASE_ID} from './compositions/OrionAdaptiveShowcase';
import {sampleProject} from './core/sampleProject';

export const OrionAdaptiveRoot:React.FC = () => <>
  <Composition
    id={ORION_ADAPTIVE_SHOWCASE_ID}
    component={OrionAdaptiveShowcase}
    durationInFrames={ORION_ADAPTIVE_SHOWCASE_DURATION}
    fps={sampleProject.brief.fps}
    width={sampleProject.brief.width}
    height={sampleProject.brief.height}
    defaultProps={{}}
  />
</>;

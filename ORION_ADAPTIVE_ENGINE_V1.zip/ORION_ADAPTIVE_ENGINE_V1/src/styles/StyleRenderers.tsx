import React from 'react';
import {interpolate, spring} from 'remotion';
import {StyleRendererProps} from '../core/types';

const clamp = {extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const fade = (f:number,a=0,b=24) => interpolate(f,[a,b],[0,1],clamp);
const rise = (f:number,from=70,to=0,a=0,b=28) => interpolate(f,[a,b],[from,to],{...clamp});
const base: React.CSSProperties = {position:'absolute',inset:0,overflow:'hidden',fontFamily:'Arial,Helvetica,sans-serif'};
const Eyebrow:React.FC<{children:string;color:string}> = ({children,color}) => <div style={{fontSize:22,fontWeight:800,letterSpacing:4,color,textTransform:'uppercase'}}>{children}</div>;
const Headline:React.FC<{children:string;color:string;size?:number}> = ({children,color,size=76}) => <div style={{fontSize:size,fontWeight:900,lineHeight:0.98,letterSpacing:-3,color,maxWidth:900}}>{children}</div>;

export const CinematicRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const p=fade(frame,0,35); const drift=interpolate(frame,[0,300],[0,-90],clamp); const pulse=1+Math.sin(frame*.025)*.018;
  return <div style={{...base,background:'linear-gradient(160deg,#0c151c 0%,#26343a 48%,#090e13 100%)'}}>
    <div style={{position:'absolute',inset:'-10%',background:`radial-gradient(ellipse at 72% 34%, ${accent}55, transparent 34%), radial-gradient(ellipse at 25% 78%, #b6a28b33, transparent 40%)`,transform:`translateY(${drift}px) scale(${pulse})`}}/>
    <div style={{position:'absolute',right:-120,top:220,width:760,height:1100,background:'linear-gradient(110deg,#d9c8ae22,#ffffff05)',transform:`skewX(-16deg) translateY(${drift*.4}px)`,filter:'blur(4px)'}}/>
    <div style={{position:'absolute',left:95,right:95,bottom:210,opacity:p,transform:`translateY(${rise(frame) }px)`}}>
      <Eyebrow color={accent}>{scene.eyebrow}</Eyebrow><div style={{height:30}}/><Headline color="#f4f0e8">{scene.headline}</Headline><div style={{height:30}}/><div style={{fontSize:31,lineHeight:1.4,color:'#d6d8d6',maxWidth:800}}>{scene.body}</div>
    </div>
    <div style={{position:'absolute',left:0,right:0,bottom:0,height:390,background:'linear-gradient(transparent,#05090dcc)'}}/>
    <div style={{position:'absolute',left:'48%',top:360,width:360,height:900,background:'linear-gradient(90deg,transparent,#0b1118aa,transparent)',filter:'blur(24px)',transform:`translateX(${Math.sin(frame*.012)*35}px)`,opacity:.65}}/>
    <div style={{position:'absolute',right:72,top:90,color:'#ffffff77',fontSize:18,letterSpacing:3}}>ORION / 0{index+1}</div>
  </div>;
};

export const EditorialRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const y=rise(frame,110,0,0,25); const scale=interpolate(frame,[0,40],[.94,1],clamp); const bar=interpolate(frame,[12,70],[0,760],clamp);
  return <div style={{...base,background:'#F2EEE5',color:'#202522',padding:88,boxSizing:'border-box'}}>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><Eyebrow color="#66665e">{scene.eyebrow}</Eyebrow><div style={{fontSize:20,fontWeight:800}}>ORION / 0{index+1}</div></div>
    <div style={{position:'absolute',top:390,left:88,right:70,transform:`translateY(${y}px) scale(${scale})`}}>
      <div style={{fontSize:28,color:'#77766e',fontWeight:700,marginBottom:35}}>THE IDEA</div>
      <Headline color="#202522" size={94}>{scene.headline}</Headline>
      <div style={{height:18}}/><div style={{height:12,width:bar,background:accent,borderRadius:8}}/>
      <div style={{fontSize:34,lineHeight:1.4,maxWidth:820,marginTop:55,color:'#51564f'}}>{scene.body}</div>
    </div>
    <div style={{position:'absolute',right:65,bottom:230,fontSize:210,fontWeight:900,color:`${accent}22`,letterSpacing:-15}}>0{index+1}</div>
    <div style={{position:'absolute',left:88,bottom:95,width:900,borderTop:'2px solid #c9c5bb',paddingTop:20,fontSize:19,letterSpacing:2,color:'#77766e'}}>ORION CREATIVE — VISUAL COMMUNICATION SYSTEM</div>
  </div>;
};

export const Technical3DRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const rot=frame*.55; const pulse=1+Math.sin(frame*.06)*.025; const reveal=fade(frame,8,45);
  return <div style={{...base,background:'radial-gradient(circle at 50% 42%,#23343d,#0b1218 72%)',color:'#eaf1ef'}}>
    <div style={{position:'absolute',left:80,top:100}}><Eyebrow color={accent}>{scene.eyebrow}</Eyebrow></div>
    <svg viewBox="0 0 1080 1100" style={{position:'absolute',top:260,width:'100%',height:1050}}>
      <g transform={`translate(540 500) rotate(${rot*.35}) scale(${pulse})`} stroke={accent} strokeWidth="5" fill="none" opacity=".8">
        <ellipse rx="300" ry="125" transform="rotate(25)"/><ellipse rx="300" ry="125" transform="rotate(-35)"/><ellipse rx="160" ry="280" transform="rotate(60)"/>
      </g>
      <g transform={`translate(540 500) rotate(${rot})`}>
        <path d="M0 -205 L170 -110 L170 100 L0 205 L-170 100 L-170 -110 Z" fill="#172932" stroke={accent} strokeWidth="9"/>
        <path d="M0 -205 L0 205 M-170 -110 L0 -10 L170 -110 M-170 100 L0 0 L170 100" stroke="#d8e4e1" strokeWidth="5" fill="none" opacity=".8"/>
        <circle r="92" fill="#0a1118" stroke={accent} strokeWidth="12"/><circle r="48" fill={accent} opacity=".85"/><circle r="17" fill="#f2eee5"/>
      </g>
      {[-1,1].map((s)=><g key={s} transform={`translate(${540+s*285} ${500+s*115})`} opacity={reveal}><path d="M0 0 L90 -90 L150 -90" stroke={accent} strokeWidth="3" fill="none"/><circle cx="150" cy="-90" r="8" fill={accent}/></g>)}
    </svg>
    <div style={{position:'absolute',left:85,right:85,bottom:190}}><Headline color="#f1f4ef" size={68}>{scene.headline}</Headline><div style={{fontSize:27,color:'#aebcbd',marginTop:28,lineHeight:1.35}}>{scene.body}</div></div>
    <div style={{position:'absolute',right:80,top:100,fontSize:19,color:'#8da0a4'}}>MECHANISM STUDY / 0{index+1}</div>
  </div>;
};

export const CharacterRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const bob=Math.sin(frame*.11)*12; const arm=Math.sin(frame*.08)*18; const popIn=spring({frame:Math.max(0,frame-5),fps:30,config:{damping:13,stiffness:110}});
  return <div style={{...base,background:'#f5eadc',color:'#242523'}}>
    <div style={{position:'absolute',top:100,left:85,right:85}}><Eyebrow color="#68645c">{scene.eyebrow}</Eyebrow></div>
    <svg viewBox="0 0 1080 1050" style={{position:'absolute',top:290,width:'100%',height:1000}}>
      <ellipse cx="540" cy="850" rx="330" ry="55" fill="#d9cbb9"/>
      <g transform={`translate(540 ${510+bob}) scale(${popIn})`}>
        <circle cx="0" cy="-145" r="115" fill="#d99072" stroke="#282725" strokeWidth="12"/>
        <path d="M-95 -180 Q-75 -310 20 -260 Q115 -270 110 -155 Q35 -220 -95 -180" fill="#282725"/>
        <circle cx="-38" cy="-145" r="10" fill="#282725"/><circle cx="40" cy="-145" r="10" fill="#282725"/><path d="M-35 -95 Q0 -65 35 -95" stroke="#282725" strokeWidth="9" fill="none" strokeLinecap="round"/>
        <path d="M-100 -20 Q0 -75 100 -20 L140 250 L-140 250 Z" fill={accent} stroke="#282725" strokeWidth="12"/>
        <path d={`M-90 15 L${-205+arm} 155 M90 15 L${205-arm} 155`} stroke="#d99072" strokeWidth="34" strokeLinecap="round"/>
        <path d="M-80 250 L-105 410 M80 250 L105 410" stroke="#282725" strokeWidth="45" strokeLinecap="round"/>
      </g>
      <g transform={`translate(790 ${300-Math.sin(frame*.09)*12}) rotate(-5)`}><rect x="-100" y="-80" width="200" height="125" rx="24" fill="#fffaf2" stroke="#282725" strokeWidth="8"/><path d="M-45 -20 L-10 12 L55 -45" stroke={accent} strokeWidth="12" fill="none" strokeLinecap="round"/></g>
    </svg>
    <div style={{position:'absolute',bottom:180,left:85,right:85}}><Headline color="#242523" size={70}>{scene.headline}</Headline><div style={{fontSize:28,lineHeight:1.35,marginTop:24,color:'#615e57'}}>{scene.body}</div></div>
    <div style={{position:'absolute',right:80,top:100,fontWeight:800}}>ORION / 0{index+1}</div>
  </div>;
};

export const IsometricRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const travel=interpolate(frame,[0,300],[0,220],clamp); const glow=.45+Math.sin(frame*.08)*.12;
  return <div style={{...base,background:'#e9ede6',color:'#25302c'}}>
    <div style={{position:'absolute',left:80,top:95}}><Eyebrow color="#66716a">{scene.eyebrow}</Eyebrow></div>
    <svg viewBox="0 0 1080 1100" style={{position:'absolute',top:270,width:'100%',height:1000}}>
      <g transform="translate(540 510)">
        <path d="M-390 80 L0 -145 L390 80 L0 305 Z" fill="#d4ddd3" stroke="#6f7d73" strokeWidth="5"/>
        <path d="M-260 35 L0 -115 L260 35 L0 185 Z" fill="#f7f5ed" stroke="#88958a" strokeWidth="4"/>
        {[0,1,2].map(i=><g key={i} transform={`translate(${-180+i*180} ${60-i*52})`}><path d="M0 0 L0 -145 L105 -205 L105 -60 Z" fill="#c1cec2" stroke="#65766b" strokeWidth="5"/><path d="M0 -145 L105 -205 L205 -150 L105 -90 Z" fill="#edf1e8" stroke="#65766b" strokeWidth="5"/><path d="M105 -90 L205 -150 L205 -5 L105 55 Z" fill="#9eafa2" stroke="#65766b" strokeWidth="5"/></g>)}
        <path d={`M-250 160 L${-250+travel} ${160-travel*.48}`} stroke={accent} strokeWidth="12" strokeLinecap="round" fill="none" strokeDasharray="18 14"/>
        <g transform={`translate(${-250+travel} ${160-travel*.48})`}><path d="M-28 -24 L0 -45 L28 -24 L0 -3 Z" fill={accent} stroke="#26302b" strokeWidth="5"/><path d="M-28 -24 L-28 15 L0 35 L0 -3 Z" fill="#b9c6b9" stroke="#26302b" strokeWidth="5"/><path d="M0 -3 L28 -24 L28 15 L0 35 Z" fill="#7e9283" stroke="#26302b" strokeWidth="5"/></g>
      </g>
    </svg>
    <div style={{position:'absolute',bottom:185,left:85,right:85}}><Headline color="#26302b" size={69}>{scene.headline}</Headline><div style={{fontSize:28,lineHeight:1.35,marginTop:24,color:'#58655d'}}>{scene.body}</div></div>
    <div style={{position:'absolute',right:80,top:95,color:'#65736a',fontWeight:800}}>PROCESS MAP / 0{index+1}</div>
    <div style={{position:'absolute',left:80,top:210,width:920,height:5,background:`linear-gradient(90deg,${accent},transparent)`,opacity:glow}}/>
  </div>;
};

export const FuturisticDataRenderer:React.FC<StyleRendererProps> = ({scene,frame,accent,index}) => {
  const sweep=interpolate(frame,[0,300],[-250,1250],clamp); const pulse=.7+Math.sin(frame*.1)*.2;
  const nodes=[{x:540,y:420},{x:300,y:610},{x:780,y:610},{x:390,y:850},{x:690,y:850}];
  return <div style={{...base,background:'radial-gradient(circle at 50% 40%,#172b35,#081017 75%)',color:'#edf4f2'}}>
    <div style={{position:'absolute',inset:0,backgroundImage:'linear-gradient(#9ab2b211 1px,transparent 1px),linear-gradient(90deg,#9ab2b211 1px,transparent 1px)',backgroundSize:'60px 60px',opacity:.45}}/>
    <div style={{position:'absolute',top:100,left:80}}><Eyebrow color={accent}>{scene.eyebrow}</Eyebrow></div>
    <svg viewBox="0 0 1080 1100" style={{position:'absolute',top:240,width:'100%',height:1000}}>
      {nodes.slice(1).map((n,i)=><line key={i} x1={nodes[0].x} y1={nodes[0].y} x2={n.x} y2={n.y} stroke={accent} strokeWidth="4" opacity={pulse}/>) }
      {nodes.map((n,i)=><g key={i}><circle cx={n.x} cy={n.y} r={i===0?58:34} fill="#10222b" stroke={accent} strokeWidth="6"/><circle cx={n.x} cy={n.y} r={i===0?17:10} fill={accent}/></g>)}
      <path d={`M${sweep} 350 L${sweep+140} 350`} stroke="#ffffff" strokeWidth="5" opacity=".6"/>
    </svg>
    <div style={{position:'absolute',left:85,right:85,bottom:180}}><Headline color="#eff5f1" size={70}>{scene.headline}</Headline><div style={{fontSize:28,lineHeight:1.4,color:'#aab9ba',marginTop:26}}>{scene.body}</div></div>
    <div style={{position:'absolute',right:80,top:100,fontSize:18,color:'#8ba2a8',letterSpacing:2}}>SIGNAL / 0{index+1}</div>
  </div>;
};

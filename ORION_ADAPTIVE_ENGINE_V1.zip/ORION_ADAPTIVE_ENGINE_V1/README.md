# ORION Adaptive Visual Storytelling Engine V1

A modular Remotion starter implementing six distinct visual languages with a transparent rule-based adaptive art director.

## Included

- Typed production brief, art direction, and scene-beat schema.
- Adaptive style selector based on content type.
- Six independent visual renderers: cinematic, technical 3D-inspired SVG, editorial, character explainer, isometric simulation, and futuristic data.
- One 60-second vertical showcase with six 10-second scenes.
- Optional audio-file prop for a continuous soundtrack or voice-over.
- Separate root composition to preserve existing project compositions.

## Integration into `agoescool28-art/orion-remotion`

Copy the `src/core`, `src/styles`, `src/components`, `src/compositions`, and `src/OrionAdaptiveRoot.tsx` files into the existing repository. Do not replace the existing `src/Root.tsx` or delete older compositions.

In the existing `src/Root.tsx`, add:

```tsx
import {OrionAdaptiveRoot} from './OrionAdaptiveRoot';
```

Then render `<OrionAdaptiveRoot />` inside the existing root fragment, alongside the current compositions:

```tsx
export const RemotionRoot: React.FC = () => (
  <>
    {/* Keep every existing composition here. */}
    <OrionAdaptiveRoot />
  </>
);
```

If the existing root has a different structure, add the component within its returned JSX without replacing existing registrations.

## Preview and render

```bash
npx remotion studio src/index.ts
```

```bash
npx remotion render src/index.ts OrionAdaptiveShowcaseV1 out/orion-adaptive-showcase-v1.mp4 --codec h264 --audio-codec aac --overwrite
```

The showcase is 1080x1920, 30 fps, 60 seconds, 1800 frames. It does not include a bundled soundtrack by default. To add one, pass an audio filename from `public/` as the `audioFile` prop and update the composition `defaultProps`.

## Important technical boundary

The Technical 3D renderer in this first foundation is a procedural SVG depth/rotation study, not a full polygonal 3D engine. True 3D model import, physically based lighting, and camera orbit require a dedicated Three.js/React Three Fiber implementation and suitable 3D assets. The other modules are visual foundations and should be refined against the supplied reference videos before being treated as production-ready.

## Validation

This source package has not been bundled or rendered against the user's Codespaces repository. After copying it, run the preview and render commands above. A successful TypeScript check alone is not proof of a successful Remotion bundle or MP4 render.

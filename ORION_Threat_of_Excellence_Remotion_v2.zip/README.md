# ORION Motion Graphic Engine v2 — The Threat of Excellence

## Jalankan
```bash
npm install
npm run start
npm run render
```

- 1080 × 1920, 30 FPS, 2236 frames (~74.53 detik)
- Voice-over asli disertakan di `public/voiceover.mp3`
- 8 beat visual dengan metafora SVG, motion halus, kinetic typography, transisi fade dan animasi `spring`
- Render membutuhkan Node.js dan akses npm.
